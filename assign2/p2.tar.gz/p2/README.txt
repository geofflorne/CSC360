CSC360 Assignment 2
Geoffrey Lorne
V00802043

Compile:
gcc MFS.c -pthread -o MFS

Run:
./MFS flows.txt

Where flows.txt is a file containg the flows.

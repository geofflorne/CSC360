CSC360 Assignment 1
Geoffrey Lorne
V00802043

Compile:
gcc PMan.c -lreadline -lhistory -o PMan

Run:
./PMan

Commands:
bg <cmd>
bglist <pid>
bgkill <pid>
bgstop <pid>
bgstart <pid>
pstat <pid>

